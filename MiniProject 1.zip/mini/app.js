const express = require('express');
const path = require('path');
const app = express();
const port = 3000;

// Middleware to serve static files from the "public" directory
app.use(express.static(path.join(__dirname, 'public')));

// Import JSON data
const items = require('./data/items.json');

// Route to serve JSON data
app.get('/api/items', (req, res) => {
  res.json(items);
});

// Start the server
app.listen(port, () => {
  console.log(`Server is running at http://localhost:${port}`);
});