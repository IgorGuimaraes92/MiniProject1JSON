document.getElementById('loadData').addEventListener('click', async () => {
    const response = await fetch('/api/items');
    const data = await response.json();
    const dataContainer = document.getElementById('dataContainer');
    dataContainer.innerHTML = ''; // Clear existing content
    data.forEach(item => {
      const itemDiv = document.createElement('div');
      itemDiv.className = 'item';
      itemDiv.innerHTML = `<h3>${item.name}</h3><p>${item.description}</p>`;
      dataContainer.appendChild(itemDiv);
    });
  });  